
package comercioelectronico;
import java.util.ArrayList;

public class Pedido {
    private ArrayList<Producto> productos;
    private double total;

    public Pedido() {
        this.productos = new ArrayList<>();
        this.total = 0.0;
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public double calcularTotal() {
        total = 0;
        for (Producto p : productos) {
            total += p.getPrecio();
        }
        return total;
    }

    @Override
    public String toString() {
        StringBuilder resumen = new StringBuilder("Pedido:\n");
        for (Producto p : productos) {
            resumen.append(p).append("\n");
        }
        resumen.append("Total del pedido: $").append(calcularTotal());
        return resumen.toString();
    }
}