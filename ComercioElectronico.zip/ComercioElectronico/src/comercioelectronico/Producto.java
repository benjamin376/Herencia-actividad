package comercioelectronico;

public class Producto {
    protected String idProducto;
    protected String nombre;
    protected double precio;

    public Producto(String idProducto, String nombre, double precio) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.precio = precio;
    }

    public double calcularDescuento(double descuento) {
        return precio - (precio * descuento / 100);
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return "Producto: " + nombre + " | Precio: $" + precio;
    }
}