package comercioelectronico;

import java.util.Scanner;

public class ComercioElectronico {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cliente cliente = new Cliente("C001", "Pedrito Paredes");
        boolean salir = false;

        while (!salir) {
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1. Explorar productos");
            System.out.println("2. Comprar productos");
            System.out.println("3. Ver pedidos");
            System.out.println("4. Salir");
            System.out.print("Elige una opcion: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    explorarProductos();
                    break;
                case 2:
                    comprarProducto(scanner, cliente);
                    break;
                case 3:
                    cliente.mostrarPedidos();
                    break;
                case 4:
                    salir = true;
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
        scanner.close();
    }

    public static void explorarProductos() {
        System.out.println("\n--- Productos Disponibles ---");
        Electronico laptop = new Electronico("E001", "Laptop", 1000.0, "Dell", 24);
        Ropa camiseta = new Ropa("R001", "Camiseta", 20.0, "M", "Rojo");

        System.out.println(laptop);
        System.out.println(camiseta);
    }

    public static void comprarProducto(Scanner scanner, Cliente cliente) {
        Pedido pedido = new Pedido();
        boolean comprar = true;

        while (comprar) {
            System.out.println("\n--- Compra de Productos ---");
            System.out.println("1. Comprar Laptop (Dell)");
            System.out.println("2. Comprar Camiseta (Roja)");
            System.out.println("3. Finalizar compra");
            System.out.print("Elige un producto: ");
            int opcionProducto = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcionProducto) {
                case 1:
                    Electronico laptop = new Electronico("E001", "Laptop", 1000.0, "Dell", 24);
                    pedido.agregarProducto(laptop);
                    System.out.println("Laptop añadida al pedido.");
                    break;
                case 2:
                    Ropa camiseta = new Ropa("R001", "Camiseta", 20.0, "M", "Rojo");
                    pedido.agregarProducto(camiseta);
                    System.out.println("Camiseta añadida al pedido.");
                    break;
                case 3:
                    cliente.agregarPedido(pedido);
                    System.out.println("Compra finalizada.");
                    comprar = false;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
}
