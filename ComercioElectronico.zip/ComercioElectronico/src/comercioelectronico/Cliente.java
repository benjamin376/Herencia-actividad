package comercioelectronico;

import java.util.ArrayList;

public class Cliente {
    private String idCliente;
    private String nombre;
    private ArrayList<Pedido> pedidosRealizados;

    public Cliente(String idCliente, String nombre) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.pedidosRealizados = new ArrayList<>();
    }

    public void agregarPedido(Pedido pedido) {
        pedidosRealizados.add(pedido);
    }

    public void mostrarPedidos() {
        System.out.println("Pedidos de " + nombre + ":");
        for (Pedido pedido : pedidosRealizados) {
            System.out.println(pedido);
        }
    }

    @Override
    public String toString() {
        return "Cliente: " + nombre;
    }
}